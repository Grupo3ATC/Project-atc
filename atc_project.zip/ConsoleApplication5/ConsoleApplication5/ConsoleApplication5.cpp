#include <string>
#include <iostream>
#include <fstream>
#include <stdlib.h>

using namespace std;


class bmp_struct
{
public:
	bmp_struct();
	~bmp_struct();
	struct bmp_signature
	{
		unsigned char dados[2];
	};
	#pragma pack (1) //as variaveis v�o estar alinhadas byte a byte evitando o padding
	struct bmp_header
	{
		bmp_signature assinatura;
		unsigned int tam_ficheiro;
		unsigned short reseverd_1;
		unsigned short reseverd_2;
		unsigned int data_offset;
	};
	#pragma pack (1)
	struct dib_header
	{
		unsigned int number_of_bytes;
		unsigned int largura;
		unsigned int comprimento;
		unsigned short number_of_colours;
		unsigned short number_of_bits;
		unsigned int BI_RGB;
		unsigned int size_raw;
		unsigned int print_resolution_1;
		unsigned int print_resolution_2;
		unsigned int n_colours_pallete;
		unsigned int important_colours;
	};

	void ler_bmp_header(ifstream &leitor, bmp_header &header);
	void ler_dib_header(ifstream &leitor, dib_header &header);
	void ler_nome_fich(string &nome);
	void imp_bmp_header(bmp_header header);
	void imp_dib_header(dib_header header);
	string nome;
	ifstream leitor;
	void abrir_fich(ifstream &leitor, string nome);
	struct bmp_header bhead;
	struct dib_header dhead;


private:
	
	
};

bmp_struct::bmp_struct()
{
}

bmp_struct::~bmp_struct()
{
}
void bmp_struct::ler_bmp_header(ifstream &leitor, bmp_header &header) {
	
	if (!leitor) return ; //so acontece se o leitor n estiver aberto

	leitor.seekg(0, leitor.beg);
	leitor.read((char*) &header, sizeof (header) );

}

void bmp_struct::ler_dib_header(ifstream &leitor, dib_header &header) {

	if (!leitor) return; //so acontece se o leitor n estiver aberto

	leitor.read((char*)&header, sizeof(header));

}

void bmp_struct::ler_nome_fich(string &nome) {

	size_t enc;
	cout << "Qual e o nome do ficheiro ?" << endl;
	cin >> nome;

	enc = nome.find('.bmp');

	if (enc == string::npos) cout << "Ficheiro Invalido" << endl;
}

void bmp_struct::imp_bmp_header(bmp_header header)
{
	cout << "==== BMP HEADER ====" << endl;
	cout << header.assinatura.dados[0] << header.assinatura.dados[1] << endl;
	cout << "+ File Size  : " << header.tam_ficheiro << " byte(s)" << endl;
	cout << "+ Reserved1  : " << header.reseverd_1 << endl;
	cout << "+ Reserved2  : " << header.reseverd_2 << endl;
	cout << "+ Data Offset: " << header.data_offset<< " byte(s)" << endl;

}
void bmp_struct::imp_dib_header(dib_header header) {

	cout << "==== DIB HEADER ====" << endl;
	cout << "Number of bytes in the DIB header" << header.number_of_bytes << endl;
	cout << "width : " << header.largura << "Pixels" << endl;
	cout << "height : " << header.comprimento << "Pixels" << endl;
	cout << "Number of color planes being used : " << header.number_of_colours << endl;
	cout << "Number of bits per pixel : " << header.number_of_bits << "Bits" << endl;
	cout << "BI_RGB, no pixel array compression used : " << header.BI_RGB << endl;
	cout << "Size of the raw bitmap data (including padding) : " << header.size_raw << "Bytes" << endl;
	cout << "Print resolution of the image : " << header.print_resolution_1 << "Pixels horizontal" << endl;
	cout << "Print resolution of the image : " << header.print_resolution_2 << "Pixels vertical" << endl;
	cout << "Number of colors in the palette : " << header.n_colours_pallete << endl;
	cout << "all colors are important : " << header.important_colours << endl;

}

void bmp_struct::abrir_fich(ifstream & leitor, string nome)
{
	leitor.open( nome, fstream::in | fstream::binary);

}

int main()
{
	char c;
	string nome;
	size_t enc;
	ifstream ifs;  // como se fosse o myfile
	int f=0; // contador
	bmp_struct container;

	container.ler_nome_fich(container.nome);
	container.abrir_fich(container.leitor, container.nome);
	container.ler_bmp_header(container.leitor,container.bhead);
	container.imp_bmp_header(container.bhead);
	container.ler_dib_header(container.leitor, container.dhead);
	container.imp_dib_header(container.dhead);




	
	/*
	if (enc!=string::npos) {
		cout << "Ficheiro Valido" << endl;
		ifs.open("bmpt.bmp", fstream::in | fstream::binary);

		while (ifs.get(c))
		{
			//ifs.;
			//ifs >> hex >> c;
			f++;
			cout << c;
		}

		cout << endl << "Nbytes" << f<< endl;

		system("PAUSE");
	}
	



	ifs.close();
	*/


	return 0;
}


